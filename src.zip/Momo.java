
public class Momo {
public static void main(String[] args) {
	int su =1;
}
	String abc = "abc";
}
