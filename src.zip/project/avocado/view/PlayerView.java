package project.avocado.view;

public class PlayerView {
	
	public PlayerView() {
		
	}
	
	
	

}
