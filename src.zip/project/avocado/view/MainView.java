package project.avocado.view;

public class MainView {
	
	public MainView() {
		
	}
	
	
	

}
