
public class Controller {
	
	public Controller() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		new Controller();
		String abd = "abc";
		String aaa = "ddd";
	}
	
	
}
